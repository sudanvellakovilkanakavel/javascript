function getoutput()
{

    var	a = 1;
    var b=" ";
    do 
    {


       b = b +"#";
       console.log(b);
       a = a + 1;

     }while(a<=7);

}


getoutput();
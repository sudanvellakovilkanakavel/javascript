function min (a,b)
{
  if (a>b)
  {
  	console.log(b);
  	return b;
  }
  else if (a==b)
  {
     consloe.log(a);
     return a;
  }
  else
  {
  	console.log (a);
  	return a;
  }

}

min (2,5);
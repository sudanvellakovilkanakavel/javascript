var	a = 1;
do 
{

var b = "#";	
console.log(b);
b = b +"#";
a = a + 1;

}while(a<=7);
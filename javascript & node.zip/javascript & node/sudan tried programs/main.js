// odd function starts
function getoddline(filename)
{
   var fs = require("fs");

   fs.readFile(filename,'utf8',function (err, data) 
   {
       if (err) 
    	{
    		return console.error(err);

    	}
    
       var lines = data.split("\n");
       //printing odd numbers
       for (i=0;i<=lines.length;)
       {
         console.log(lines[i]);
         i=i+2;
       }
   });
  console.log("Program Ended");
}
//odd function ends
//even function starts
function getevenline(filename)
{
   var fs = require("fs");

   fs.readFile(filename,'utf8',function (err, data) 
   {
       if (err) 
      {
        return console.error(err);

      }
    
       var lines = data.split("\n");
       //printing even numbers
       for (i=1;i<=lines.length;)
       {
          console.log(lines[i]);
          i=i+2;
       }
   });
  console.log("Program Ended");
}
//even function ends
//get file name from user
var chunk;
var typeofline;
process.stdin.setEncoding('utf8');

process.stdin.on('readable', () => 
{
   console.log("for entering file name");
  chunk = process.stdin.read();
  if (chunk !== null)
   {
     //displaying the file nam enterd by the user
     chunk=chunk.slice(0, chunk.length - 1);
     console.log(chunk);

     process.stdout.write(`data: ${chunk}`);

     getoddline(chunk);
     getevenline(chunk);
    }
    
});
process.stdin.on('end', () => 
{
  process.stdout.write('end');
});
//ending of getting file name from the user
//get typeofline to be printed from the user starts here

process.stdin.setEncoding('utf8');
process.stdin.on('readable', () => 
{
  console.log("this is for selection odd/even");
  typeofline = process.stdin.read();
  if (typeofline !== null)
   {
     //displaying the typeofline enterd by the user
     typeofline=typeofline.slice(0, chunk.length - 1);
     console.log(typeofline);
     process.stdout.write(`data>: ${typeofline}`);
//geting typeofline  to be printed from the user ends here
        //switch statement starts here
       switch (typeofline)
        {
          case 'odd': getoddline(chunk);
          break;
          case 'even': getevenline(chunk);
          break;
          case 'random': getrandom(chunk);
          break;
          default:console.log("kindly enter either odd or even or random")
         }
        //switch statement ends here
    }
});
process.stdin.on('end', () => 
{
  process.stdout.write('end');
});








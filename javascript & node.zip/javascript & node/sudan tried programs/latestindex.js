// odd function starts
function getoddline(filename)
{
   var fs = require("fs");

   fs.readFile(filename,'utf8',function (err, data) 
   {
       if (err) 
    	{
    		return console.error(err);

    	}
    
       var lines = data.split("\n");
       //printing odd numbers
       for (i=0;i<=lines.length;)
       {
         console.log(lines[i]);
         i=i+2;
       }
   });
  console.log("Program Ended");
}
//odd function ends
//even function starts
function getevenline(filename)
{
   var fs = require("fs");

   fs.readFile(filename,'utf8',function (err, data) 
   {
       if (err) 
      {
        return console.error(err);

      }
    
       var lines = data.split("\n");
       //printing even numbers
       for (i=1;i<=lines.length;)
       {
          console.log(lines[i]);
          i=i+2;
       }
   });
  console.log("Program Ended");
}
//even function ends
//get file name from user
var chunk; //variable declation for storeing file name
var typeofline;// variable declaration for storeing  typeofline
process.stdin.setEncoding('utf8');

process.stdin.on('readable', () => 
{
// reading file name from the user
  console.log("Kindly enter the file name");
  chunk = process.stdin.read();// reading the file name and storeing it in th e variable chunk
  if (chunk !== null)
   {
     //displaying the file nam enterd by the user
     chunk=chunk.slice(0, chunk.length - 1);
     

     process.stdout.write(`data: ${chunk}`);

     
    }
 
    // reading typeofline from the user
  console.log("Kindly enter even/odd/random");
  typeofline = process.stdin.read();// reading the sring even/odd/random and storeing it in the variable typeofline
  if (typeofline !== null)
   {
     //displaying the typeofline enterd by the user
     typeofline=typeofline.slice(0, chunk.length - 1);
     
     process.stdout.write(`data>: ${typeofline}`);

        //switch statement starts here
       switch (typeofline)
        {
          case 'odd': getoddline(chunk);
          break;
          case 'even': getevenline(chunk);
          break;
          case 'random': getrandom(chunk);
          break;
          default:console.log("kindly enter either odd or even or random")
         }
        //switch statement ends here
    }
    
 

//ending of getting file name & typeofline from the user































































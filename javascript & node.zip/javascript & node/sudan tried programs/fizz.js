var i=1;
do
{
	
   switch (i)
   {


       case (i%3==0) : console.log("FIZZ");
       break;

       case (i%5==0) : console.log("BUZZ");
       break;

  
       case (i%3==0 & i%5==0) : console.log("FIZZBUZZ");
       break;

       default : console.log(i);
       break;
    }

   i++;


}while(i<=100);
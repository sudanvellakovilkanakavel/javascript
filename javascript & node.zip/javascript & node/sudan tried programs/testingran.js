var fs = require("fs");
function getrandomline ()
{
    
    var randomline = Math.floor(Math.random() * 20 );
    fs.readFile('input.txt','utf8',function (err,data)
    {
       if (err) 
       {
        return console.error(err);
       }
    var lines = data.split("\n");
    console.log(lines[randomline]);
    });   
}

getrandomline();


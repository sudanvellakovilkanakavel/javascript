var n = 0;
var m = 0;
var state = 0;
process.stdin.on('data', function (input) {
    switch (state)
    {
    case 0:
        // we're reading 'n'
        n = parseInt(input.trim(), 10);
        state++;
        break;

    default:
        // we're reading 'm'
        m = parseInt(input.trim(), 10);

        if (state++ == n)
        {
            // we've read every 'm'
            process.exit();
        }
        break;
    }
});